var CLICKPDX = {
	subscriptionCallout: 'CustomHttpSendable'
};