var showMatchingFields = true;


$(function(){
		$('.fs-section').hide();


var doSearch = function(e) {
	e.preventDefault();
	e.stopPropagation();
	
	window.searchEmail = $('#contactSearch').val();
	window.selectedContact = {};
	
	CLICKPDX.ContactForm.searchContacts({Email: window.searchEmail}).then( function(results){
		console.log(results);
		return new Promise(CLICKPDX.ContactForm.newContactDialog(results));
	})
	.then( function(contact){
		selectedContact = contact;
		$('input[name*="Email"]').val(window.searchEmail);
		console.log(contact);
		for(var i in contact){
			var sel = '*[name="'+i+'"]';
			console.log('setting sel to: '+sel);
			$(sel).val(contact[i]);
		}
		$('.fs-section').show();
	})
	.catch( function(reason){
		$('.fs-section').show();	
		// console.log(reason);
		// alert(reason.message);
	});
	
	return false;
};


var doRegistration = function(e) {

	e.preventDefault();
	e.stopPropagation();
	
	var contact = window.selectedContact;
	contact.Email = $('#contactSearch').val();
	
	// for each field with a class of field-name
	  // pull the actual field name and add it as a property of this Contact object
	$('.fs-section-Contact .form-field').each(function(elem){
		var name = $(this).prop('name');
		contact[name] = $(this).val();
	});
	
	var account = {
		Id: window.selectedContact.AccountId || null,
		Name: contact.FirstName + ' ' + contact.LastName
	};

	CLICKPDX.ContactForm.doRegistration(account,contact).then( function(results){
		console.log(results);
		alert('Saved!  Should probably redirect to a welcome page that also explains that a new registration email has been sent.');
		return false;
	})
	.catch( function(reason){
			console.log(reason);
			alert(reason.message);
			return false;
	});

	return false;

};

var doSubscription = function(e){
	e.preventDefault();
	e.stopPropagation();
	var params = {
		email: 'jbernal.web.dev@gmail.com',
		firstName: 'Jose',
		lastName: 'Bernal'
	};
	CLICKPDX.ContactForm.doSubscription(params).then( function(result){
		alert(result.body);
	})
	.catch( function(error){
		console.log(error);
	});
};

 var submit = document.getElementById('searchContacts');
 submit.addEventListener('click', doSearch, false);
 
 
 
 var submit = document.getElementById('doRegistration');
 submit.addEventListener('click', doRegistration, false);
 
 var submit = document.getElementById('doSubscription');
 submit.addEventListener('click', doSubscription, false);
	
	

	
	
});