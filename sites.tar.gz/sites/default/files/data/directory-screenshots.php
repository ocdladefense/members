<?php

function getWebGovData() {
	return array(
		'notices' => array(
					// 'Wed July 27, 10 AM: Our <a href="https://docs.google.com/document/d/1ppbO3IeU6YxHhgBrmSX23zJZXDQvvA6Nv3_Fa65WFT0/edit?usp=sharing">AMS Post-launch meeting</a> has been tentatively scheduled for Thursday, Aug 4 at 9:00 am.',
					'Tue May 16, 12:30 PM: Next Web Governance Committee meeting is ___________.',
				),
		'lastUpdated' => 'June 14, 2017',
		'instructions' => "Thank you for evaluating the <a href='/directory'>OCDLA Membership and Expert Witness directories</a>.  Please email your feedback on the following directory features to <a href='mailto:tmay@ocdla.org'>Tracye</a>: <ol><li>Search form</li><li>Search results</li><li>Member profiles</li></ol>Our goal is to identify areas in the directory that can be improved.  Specifically, the directory should be easily navigable on both desktop, tablet and phone devices; it should provide accurate search results and should display enough information on a member's profile to be useful.",
		'sections' => getDirectoryScreenshots()
	);
}



	function getDirectoryScreenshots()
	{
		$section1 = array(
			'title' => 'Search Form',
			'description' => 'Lorem ipsum.',
			'screenshots' => array(
				array(
					'title' => 'OCDLA Search Form - Desktop',
					'url' => 'search-form-desktop.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'The search form should appear as formatted for wide-screen devices.',
				),
				array(
					'title' => 'OCDLA Search Form - Tablet',
					'url' => 'search-form-tablet.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'The search form should appear as formatted for tablet devices.  The left menu should be hidden and replaced by the top-right menu icon.',
				),
				array(
					'title' => 'OCDLA Search Form - Phone',
					'url' => 'search-form-phone.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'The search form should appear as formatted for mobile-phone devices.  The layout should be displayed in a single column so the user doesn\'t have to pan left or right to see content that might otherwise show outside of the display portal.',
				)
			)
		);
			
		$section2 = array(
			'title' => 'Search results',
			'description' => 'The below screenshots are representative of what search results within the OCDLA directory should look like.',
			'screenshots' => array(
				array(
					'title' => 'OCDLA Search Results - Desktop',
					'url' => 'search-results-desktop.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'The search results should appear as formatted for wide-screen devices.',
				),
				array(
					'title' => 'OCDLA Search Results - Tablet',
					'url' => 'search-results-tablet.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'The search results should appear as formatted for tablet devices.',
				),
				array(
					'title' => 'OCDLA Search Results - Phone',
					'url' => 'search-results-phone.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'The search form should appear as formatted for phone devices.',
				),
			)
		);
		
		$section3 = array(
			'title' => 'Member/Expert profiles',
			'description' => 'Lorem ipsum.',
			'screenshots' => array(
				array(
					'title' => 'Member Profile - Desktop',
					'url' => 'member-profile-desktop.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'Individual member profiles as formatted for wide-screen devices.',
				),
				array(
					'title' => 'Expert Witness Profile - Desktop',
					'url' => 'expert-witness-profile.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'Expert Witness profiles as formatted for wide-screen devices.',
				),
				array(
					'title' => 'Member Profile - Tablet',
					'url' => 'member-profile-tablet.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'Individual member profiles as formatted for tablet devices.',
				),
				array(
					'title' => 'Member Profile - Phone',
					'url' => 'member-profile-phone.png',
					'summary' => 'OCDLA Search Form - Desktop',
					'date_completed' => 'Oct 3, 12:00 PM',
					'description' => 'Individual member profiles as formatted for phone devices.',
				),
			)
		);
		
		
		return array($section1,$section2,$section3);
	}