<?php

function getWebGovData() {
	return array(
		'notices' => array(
			'The next Web Governance Committee meeting is <em>Monday, July 31, 12:15 PM</em>.  <ul>Subsequent meetings are as follows: <li>Mon, Aug 28</li><li>Mon, Sept 25</li><li>Mon, Oct 30</li><li>Mon, Nov 27</li><li>Tues, Dec 26</li></ul>'
		),
		'lastUpdated' => 'June 28, 2017',
		'links' => getWebGovLinks(),
		'projects' => getWebGovProjects()
	);
}


function getWebGovLinks() {
	return array(
		array(
			'url' => 'https://docs.google.com/document/d/1kMXpyHL0aDS6j5jJEQQ39K2HmWWegXmAsaklXNvKD-8/edit?usp=sharing',
			'name' => 'Books Online - Sample Feature Schedule (7/10/2017)'
		),
	 	array(
	  'url' => 'https://docs.google.com/spreadsheets/d/1WmPBSV7BQTlcGmv93xpIvJplqoNpvZASCfJIgz6s-V4/edit#gid=1191824628',
	  'name' => 'Directory evaluation - committee feedback'
	 ),
	 array(
	  'url' => '/committees/webgov/directory-screenshots',
	  'name' => 'Directory evaluation - reference screenshots'
	 ),
	 array(
	 	'url' => 'https://docs.google.com/spreadsheets/d/175zea7knpeQnt6hOMC74sNxtev44Std8vrb2Luxl9sg/edit?usp=sharing',
	 	'name' => 'WebGov Tech Checklist'
	 ),
	 array(
	  'url' => 'https://docs.google.com/spreadsheets/d/1YgzLRM_Nn0Daq1UZEXIPR7eo42H1tr_nxl6A5MUdwuE/edit#gid=0',
	  'name' => 'LOD Dictionary'
	 ),
	 array(
	  'url' => 'https://docs.google.com/spreadsheets/d/1G1gZhaLwZFs49SnjXs5nM4DERDVgaxE1M_4ox2hRCac/edit?usp=sharing',
	  'name' => 'MediaWiki Upgrade Outline/Estimate'
	 )
	 
	);

}

	function getWebGovProjects()
	{
		return array(
			array(
				'title' => 'Expert Witness Database',
				'summary' => 'The <a href="https://auth.ocdla.org/login1.php?retURL=https%3A%2F%2Fmembers.ocdla.org%2Fdirectory%2Fexpert-witness%2Fsearch">Expert Witness Database</a> is now available for OCDLA members.  Please note: members must be logged-in to browse the Expert Witness directory.',
				'date_completed' => 'May 5, 2017',
				'description' => 'Experts have been assigned to new, more search-friendly categories.  Jennifer will be soliciting revised information from Experts after the OCDLA Annual Conference.',
				'thumbnail' => 'dashboard.png'
			)
		);
	}